class Config{
    //backend routes
    public baseURL = "http://localhost:3001";
    public addVacation = this.baseURL+"/api/addVacation";
    public getAllVacation = this.baseURL+"/api/vacation";
    public addUser = this.baseURL+"/api/register/";
    public users = this.baseURL+"/api/user"
    public loginUser = this.baseURL+"/api/login/";
}

const appUrl = new Config();
export default appUrl;