class UserModel {
    public id: number;
    public first_name: string;
    public last_name: string;
    public user_name: string;
    public user_password: string;
    public is_admin: number;

}

export default UserModel;