class FollowModel {
    userId: number;
    vacationId: number;
}

export default FollowModel;