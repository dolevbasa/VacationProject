class UsersModel{
    public firstName?:string;
    public user_name?: string;
    public user_password?:string;
}

export default UsersModel;