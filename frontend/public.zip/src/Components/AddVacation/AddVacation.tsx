import { Person, Password } from "@mui/icons-material";
import { Typography, TextField, Checkbox, ButtonGroup, Button, createTheme } from "@mui/material";
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router";
import UserModel from "../../model/userModel";
import groupService from "../../utils/vacationService";
import appUrl from "../../utils/Config";
// import "./Register.css";
import notify from "../../utils/Notify";
import axios from "axios";
import { red } from "@mui/material/colors";
import { VacationModel } from "../../model/vacationModel";

const theme = createTheme();

function AddVacation(): JSX.Element {

    const [account,setAccount] = useState<VacationModel[]>([]);
    //to use useFrom write this line
    const {register , handleSubmit, formState: {errors}}= useForm<VacationModel>();
    const [userData,setData] = useState<VacationModel>();
    const navigate = useNavigate();
    const params = useParams();
    const id = +(params.id || '');
    //hook form....
    async function send(vacation:VacationModel){
        try{
            await groupService.addVacation(vacation)
            notify.success(`Vacation ${vacation.destination} was added`);
            navigate("/home");
            //manual routing....
        } catch (err:any){
            notify.error(err.message);
        }
    }

    useEffect(()=>{
        console.log(id);
        if (id>0){
            //load data from data base :)
            
        }
        groupService.getAllVacation()
        .then (user => setAccount(user))
        .catch(err=>alert(err.message));
    },[]);


    return (
        <div className="Vacation Box">
            <form onSubmit={handleSubmit(send)} method={"post"} action="/" encType={"multipart/form-data"}>
                <Typography variant="h4" className="HeadLine">Register</Typography><br />
                <ArrowForwardIcon style={{ fontSize: 40, margin: 10 }} />
                <TextField label="First Name" variant="outlined"
                    inputProps={{ sx: { color: "black", backgroundColor: "white" } }}
                    InputLabelProps={{ style: { color: "black", backgroundColor: "white" } }}
                    {...register("description", {
                        required: {
                            value: true,
                            message: "Please input your First Name",
                        },
                    })}
                /><br />
                <span>{errors.description?.message}</span>
                <br /><br />
                <ArrowForwardIcon style={{ fontSize: 40, margin: 10 }} />
                <TextField label="Last Name" variant="outlined"
                    inputProps={{ sx: { color: "black", backgroundColor: "white" } }}
                    InputLabelProps={{ style: { color: "black", backgroundColor: "white" } }}
                    {...register("destination", {
                        required: {
                            value: true,
                            message: "Please input your Last Name",
                        },
                    })}
                /><br />
                <span>{errors.destination?.message}</span>
                <br /><br />
                <Person style={{ fontSize: 40, margin: 10 }} />
                <TextField
                            fullWidth
                            margin='normal'
                            variant='standard'
                            helperText="Image"
                            type="file"
                            name="image"
                            inputProps={{accept:"image/*"}}
                            {...register("image", {
                                required: { value: true, message: "Missing image" }
                            })}
                        /><br />
                <span>{errors.image?.message}</span>
                <br /><br />
                <Password style={{ fontSize: 40, margin: 10 }} />
                <TextField label="User Password" type={"datetime-local"}  variant="outlined"
                    inputProps={{ sx: { color: "black", backgroundColor: "white" } }}
                    InputLabelProps={{ style: { color: "black", backgroundColor: "white" } }}
                    {...register("from_date", {
                        required: {
                            value: true,
                            message: "Please input your Password",
                        },
                    })} />
                <br />
                <span>{errors.from_date?.message}</span>
                <br /><br />
                <Password style={{ fontSize: 40, margin: 10 }} />
                <TextField label="User Password" type={"datetime-local"}  variant="outlined"
                    inputProps={{ sx: { color: "black", backgroundColor: "white" } }}
                    InputLabelProps={{ style: { color: "black", backgroundColor: "white" } }}
                    {...register("to_date", {
                        required: {
                            value: true,
                            message: "Please input your Password",
                        },
                    })} />
                <br />
                <span>{errors.to_date?.message}</span>
                <br /><br />
                <Password style={{ fontSize: 40, margin: 10 }} />
                <TextField label="User Password" variant="outlined"
                    inputProps={{ sx: { color: "black", backgroundColor: "white" } }}
                    InputLabelProps={{ style: { color: "black", backgroundColor: "white" } }}
                    {...register("price", {
                        required: {
                            value: true,
                            message: "Please input your Password",
                        },
                    })} />
                <br />
                <span>{errors.price?.message}</span>
                <br /><br />
                <Password style={{ fontSize: 40, margin: 10 }} />
                <TextField label="User Password"  variant="outlined"
                    inputProps={{ sx: { color: "black", backgroundColor: "white" } }}
                    InputLabelProps={{ style: { color: "black", backgroundColor: "white" } }}
                    {...register("followers", {
                        required: {
                            value: true,
                            message: "Please input your Password",
                        },
                    })} />
                <br />
                <span>{errors.followers?.message}</span>
                <br /><br />
                <Button variant="contained" type="submit">Register</Button>
            </form>
        </div>
    );
}

export default AddVacation;
