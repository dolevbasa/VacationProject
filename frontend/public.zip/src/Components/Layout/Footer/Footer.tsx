import "./Footer.css";

function Footer(): JSX.Element {
    return (
        <div className="Footer">
			All rights reserved to Dolev Basa &copy;
        </div>
    );
}

export default Footer;

