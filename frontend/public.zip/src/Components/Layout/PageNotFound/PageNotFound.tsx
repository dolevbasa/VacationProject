import "./PageNotFound.css";

function PageNotFound(): JSX.Element {
    return (
        <div className="PageNotFound">
			<h1>This page is not found :(</h1>
        </div>
    );
}

export default PageNotFound;
