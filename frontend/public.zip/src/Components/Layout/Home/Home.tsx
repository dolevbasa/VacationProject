import Card from '@mui/material/Card';
import { useEffect, useState } from "react";
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import "./Home.css";
import { VacationModel } from '../../../model/vacationModel';
import groupService from '../../../utils/vacationService';
import { IconButton } from '@mui/material';
import FavoriteIcon from '@mui/icons-material/Favorite';

function Home(): JSX.Element {
    const [vacation, setVacation] = useState<VacationModel[]>([]);
    useEffect(() => {
        groupService.getAllVacation()
            .then(response => { setVacation(response); })
            .catch(err => console.log(err.message))
    }, [])
    return (
        <div className="Home">
            {vacation.map(item =>
                <Card key={item.id} className="Card">
                    <CardMedia
                        component="img"
                        height="200"
                        src={item.image}
                        alt={item.destination}
                    />
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                            {item.destination}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {item.description}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                            {"🛫" + item.from_date}
                            <br />➡️<br />
                            {"🛬" + item.to_date}
                        </Typography>
                        <br />
                        <Typography gutterBottom variant="h6" component="div">
                            {item.price + "$"} <br />
                        </Typography>
                        <IconButton aria-label="add to favorites">
                            <FavoriteIcon className="Follow" />
                        </IconButton>
                    </CardContent>
                </Card>
            )}
            {/* <img src="../../../../../backend/img/France.jpg" alt="" /> */}
        </div>
    );
}

export default Home;
