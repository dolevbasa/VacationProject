import { Button } from "@mui/material";
import { NavLink } from "react-router-dom";
import Home from "../Home/Home";
import "./Menu.css";

function Menu(): JSX.Element {
    return (
        <div className="Menu">
        </div>
    );
}

export default Menu;
