import { Logout } from "@mui/icons-material";
import { useState, useEffect } from "react";
import { Navigate, Route, Routes } from "react-router";
import { Unsubscribe } from "redux";
import { store } from "../../../Redux/Store";
import AddVacation from "../../AddVacation/AddVacation";
import Login from "../../Login/Login";
import LogOut from "../../LogOut/LogOut";
import Register from "../../Register/Register";
import Header from "../Header/Header";
import Home from "../Home/Home";
import HomePage from "../HomePage/HomePage";
import PageNotFound from "../PageNotFound/PageNotFound";
import "./Routing.css";

function Routing(): JSX.Element {
    const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
    const [isAdmin, setIsAdmin] = useState<boolean>(true);

    const unsubscribeMe: Unsubscribe = store.subscribe(() => {
        
        const user = store.getState().user;
        if (!user) {
            setIsLoggedIn(false);
            setIsAdmin(false);
        } else {
            setIsLoggedIn(true);
            //const role = user?.role;
            // if (role === Role.Admin) setIsAdmin(true);
            // if (role !== Role.Admin) setIsAdmin(false);
        }
    });

    useEffect(() => {

        let user = store.getState().user;
        if (!user) {
            setIsLoggedIn(false);
            setIsAdmin(false);
        } else {
            //const role = user?.role;
            // if (role !== Role.Admin) setIsAdmin(false);
        }
    }, []);

    useEffect( () => {
        return () => {
            unsubscribeMe();   
        };
    },  []);
    return (
        <div className="Routing">
			<Routes>
                <Route path="/home" element={isLoggedIn ? <Home /> : <Navigate to="/login" />} />
                <Route path="/login" element={<Login/>}/>
                <Route path="/logout" element={<LogOut/>}/>
                <Route path="/register" element={<Register/>}/>
                <Route path="/addVacation" element={<AddVacation/>}/>
                <Route path="/" element={<HomePage/>}/>
                <Route path="*" element={<PageNotFound/>}/>

            </Routes>
        </div>
    );
}

export default Routing;
