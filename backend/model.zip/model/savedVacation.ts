export class SavedModel {
    public user_ID: number | undefined;;
    public vacation_ID: number | undefined;
    
};