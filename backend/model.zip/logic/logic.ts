import { UserModel } from '../model/user';
import { VacationModel } from '../model/vacation'
import dal from '../utils/dal_mysql';
import { v4 as uuid } from "uuid";
import { OkPacket } from 'mysql';
import { SavedModel } from '../model/savedVacation';
import ClientError from '../model/client-errors';
import jwt from '../utils/jwt';
// users
async function getAllUsers(): Promise<UserModel[]> {
  const sql = `SELECT * FROM vacations.user;`;
  const result = await dal.execute(sql);
  return result;
}
// login
async function login(userLogin: UserModel):Promise<string> {
  const sql = `SELECT * FROM vacations.user WHERE user_name = '${userLogin.user_name}' and user_password='${userLogin.user_password}';`;
  const users = await dal.execute(sql);
  const user = users[0];

  if (!user) throw new ClientError(401, "Incorrect username or password");

    delete user.password;

    const token = jwt.getNewToken(user);

    return token;
};
// register
async function addUser(user: UserModel){

  const dbUsers = getAllUsers();
  const userInDb = (await dbUsers).find(u=> u.user_name === user.user_name);
  if(userInDb) throw new ClientError(401,"This Username Already exists!")
  const sql = `
  INSERT INTO vacations.user VALUES (DEFAULT,'${user.first_name}', '${user.last_name}', '${user.user_name}', '${user.user_password}',0);
  `;
  const info: OkPacket = await dal.execute(sql);
    user.id = info.insertId;
    delete user.user_password;
    const token = jwt.getNewToken(user);
    return token;
};

// vacations
async function getAllVacations(): Promise<UserModel[]> {
  const sql = `SELECT * FROM vacations.vacation;`;
  const result = await dal.execute(sql);
  return result;
};

async function getOneVacation(id: number) {
  const sql = `SELECT * FROM vacation WHERE id = ${id}`;
  const result = await dal.execute(sql);
  return result;
};

async function followVacation(data: SavedModel): Promise<SavedModel> {
  const sql = `INSERT INTO savedvacations(user_ID,vacation_ID)
  VALUES(${data.user_ID} ,${data.vacation_ID})`;
  const vacation = await dal.execute(sql);
  return vacation;
}

async function getFollowedVacations(id:number): Promise<SavedModel> {
  const sql = `SELECT vacationId FROM savedvacations 
WHERE userId = ${id}`;
  const vacations = await dal.execute(sql);
  return vacations;
}

async function deleteFollowedVacation(userId: number, vacationId: number):Promise<void> {
  const sql = `DELETE FROM savedvacations WHERE userId = ${userId} and vacationId = ${vacationId}`;
  await dal.execute(sql);
}

async function addNewVacation(vacation: VacationModel): Promise<VacationModel> {
  const sql = `INSERT INTO vacations.vacation VALUES(DEFAULT,
      '${vacation.description}',
      '${vacation.destination}',
      '${vacation.image}',
      '${vacation.from_date}',
      '${vacation.to_date}',
      ${vacation.price},
      0,
      ${vacation.followers}
    );`;
    const result: OkPacket = await dal.execute(sql);
    vacation.id = result.insertId;
    return vacation;
}

async function deleteVacation(id: number): Promise<void> {
  const sql = `DELETE FROM vacations.vacation WHERE id = ${id}`;
  await dal.execute(sql);
}

async function updateVacation(vacation: VacationModel): Promise<void> {
  const sql = `
      UPDATE vacations.vacation SET
      destination = '${vacation.destination}',
      description = '${vacation.description}',
      image = '${vacation.image}',
      from_date = '${fixDateFormat(vacation.from_date)}',
      to_date = '${fixDateFormat(vacation.to_date)}',
      price = ${vacation.price}
      WHERE id = ${vacation.id}`;
  const result: OkPacket = await dal.execute(sql);
}

async function getAllFollowedVacations():Promise<SavedModel>{
  const sql = 'SELECT * FROM savedvacations';
  const vacations = await dal.execute(sql);
  return vacations;
}

function fixDateFormat(date:string ) {
  const newDate = new Date(date);
  const year = newDate.getFullYear();
  const month = newDate.getMonth() + 1;
  const day = newDate.getDate();
  return `${year}-${month}-${day}`;
}
export default {
  login,
  addUser,
  getAllUsers,
  getAllVacations,
  getOneVacation,
  addNewVacation,
  followVacation,
  getFollowedVacations,
  deleteFollowedVacation,
  deleteVacation,
  updateVacation,
  getAllFollowedVacations
}