import express, { NextFunction, Request, response, Response } from "express";
import logic from "../logic/logic";
import { VacationModel } from "../model/vacation";
import fs from 'fs';
import fromidable from 'formidable'


const router = express.Router();


// login
router.post('/api/login/', async (request: Request, response: Response, next: NextFunction) => {
  try {
    const userLogin = await logic.login(request.body);
    response.status(201).json(userLogin)
  }
  catch (error: any) {
    next(error);
  }
});

// register
router.post('/api/register/', async (request: Request, response: Response, next: NextFunction) => {
  try {
    const newUser = await logic.addUser(request.body);
    response.status(201).json(newUser);
  }
  catch (error: any) {
    next(error);
  };
});

router.get("/api/user", async (request: Request, response: Response, next: NextFunction) => {
  try {
    const user = await logic.getAllUsers();
    response.status(200).json(user);
  }
  catch (err: any) {
    next(err);
  };
});

router.get("/api/vacation", async (request: Request, response: Response, next: NextFunction) => {
  try {
    const vacations = await logic.getAllVacations();
    response.status(200).json(vacations)
  }
  catch (err: any) {
    next(err)
  };
});

router.post("/api/addVacation", async (request: Request, response: Response, next: NextFunction)=>{
  try{
    const addVacation = await logic.addNewVacation(request.body);
    response.status(202).json(addVacation);
  } catch(err:any){
    next(err);
  }
});

router.get("/api/vacation/:id", async (request: Request, response: Response, next: NextFunction) => {
  try {
    const id = +request.params.id;
    const vacation = await logic.getOneVacation(id);
    response.json(vacation);

  }
  catch (err: any) {
    next(err)
  };
});

router.post('/api/followVacation', async (request: Request, response: Response, next: NextFunction) => {
  try {
    const sendInfo = await logic.followVacation(request.body);
    response.status(201).json(sendInfo);
  }
  catch (err: any) {
    next(err)
  }
});

router.get('/api/getFollowedVacations/:id', async (request: Request, response: Response, next: NextFunction) => {
  try {
    const id = +request.params.id;
    const vacations = await logic.getFollowedVacations(id);
    response.status(201).json(vacations);
  }
  catch (err: any) {
    next(err)
  }
});

// remove followed vacation
router.delete('/api/delete/:vacationId/:userId', async (request: Request, response: Response, next: NextFunction) => {
  try {
    const userId = +request.params.userId;
    const vacationId = +request.params.vacationId;
    await logic.deleteFollowedVacation(userId, vacationId);
    response.status(202).json("{msg:'done'}");
  }
  catch (err: any) {
    next(err)
  }
});

// router.post('/new-vacation', jwtLogic.verifyToken, async (request, response) => {
//   try {
//       jwt.verify(request.token, 'secretkey', (err, authData) => {
//           if (authData.user.isAdmin !== 1) {
//               throw "Error !"
//           }
//       });
//       if (!request.files) {
//           response.status(400).send('No File Sent !');
//           return;
//       }
//       const vacation = JSON.parse(request.body.vacation);
//       const file = request.files.image;
//       const randomName = uuid.v4();
//       const extension = file.name.substr(file.name.lastIndexOf('.'));
//       file.mv('../Client/public/assets/images/vacations/' + randomName + extension);
//       vacation.image = randomName + extension;
//       const newVacation = await vacationLogic.addNewVacation(vacation);
//       response.status(201).json(newVacation);
//   } catch (error) {
//       response.status(500).send(error);
//   }
// });

// router.delete('/delete-vacation', jwtLogic.verifyToken, async (request, response) => {
//   try {
//       jwt.verify(request.token, 'secretkey', (err, authData) => {
//           if (authData.user.isAdmin !== 1) {
//               throw "Error !"
//           }
//       });

//       const vacation = request.body;
//       fs.unlinkSync(`../Client/public/assets/images/vacations/${vacation.image}`);
//       await vacationLogic.deleteVacation(vacation.vacationID);
//       response.sendStatus(204);
//   } catch (error) {
//       response.status(500).send(error);
//   }
// });

// router.put('/update-vacation', jwtLogic.verifyToken, async (request, response) => {
//   try {
//       jwt.verify(request.token, 'secretkey', (err, authData) => {
//           if (authData.user.isAdmin !== 1) {
//               throw "Error !"
//           }
//       });
//       const randomName = uuid.v4();
//       const vacation = JSON.parse(request.body.vacation);
//       if (request.files) {
//           const file = request.files.image;
//           fs.unlinkSync(`../Client/public/assets/images/vacations/${vacation.image}`);
//           const extension = file.name.substr(file.name.lastIndexOf('.'));
//           file.mv('../Client/public/assets/images/vacations/' + randomName + extension);
//           vacation.image = randomName + extension;
//       }

//       const updatedVacation = await vacationLogic.updateVacation(vacation);
//       response.json(updatedVacation);

//       if (updatedVacation === null) {
//           response.sendStatus(404);
//           return;
//       }
//   } catch (error) {
//       response.status(500).send(error);
//   }
// });

// router.get('/followed/get-all', jwtLogic.verifyToken, async (request, response) => {
//   try {
//       jwt.verify(request.token, 'secretkey', (err, authData) => {
//           if (authData.user.isAdmin !== 1) {
//               throw "Error !"
//           }
//       });
//       const vacations = await vacationLogic.getAllFollowedVacations();
//       response.json(vacations);
//   } catch (error) {
//       response.status(500).send(error);
//   }
// });

export default router;